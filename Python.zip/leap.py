number = int(input("Enter the year : "))
if (number % 4 == 0):
  print(number, "is leap year.")
else:
  print(number, "is not a leap year.")
